package com.capgemini.placementsmgmt.service;

import java.util.List;
import com.capgemini.placementsmgmt.entities.Company;

public interface CompanyService {
	public Company saveCompany(Company company);

	public List<Company> getAllCompany();

	public Company getCompanyById(int id);

}
