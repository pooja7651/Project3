package com.capgemini.placementsmgmt.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.capgemini.placementsmgmt.entities.ApplyJobs;
import com.capgemini.placementsmgmt.entities.Company;
import com.capgemini.placementsmgmt.service.ApplyJobsService;
import com.capgemini.placementsmgmt.service.CompanyService;
@Controller

public class CompanyViewController {
	@Autowired
	CompanyService  companyservice;
	
	@RequestMapping("/apply1")
	public String viewcompanyPage(Model model) {
		List<Company > companyList = companyservice.getAllCompany();
		model.addAttribute("companyList",companyList);
		return "applyjobs";
		
	}
	
	@RequestMapping(value="/saveapply1",method= RequestMethod.POST)
	public String saveCompany(@ModelAttribute("company") Company company) {
		companyservice.saveCompany(company);
		return "redirect:/apply";
	}
	@RequestMapping("/add1/{id}")
	public ModelAndView showCompanyPage(@PathVariable(name = "id") int registrationid) {
		ModelAndView mav = new ModelAndView("add_newcompany");
		Company company = companyservice.getCompanyById(registrationid);
		mav.addObject("company",company);
		return mav;
	}
	

	
}
