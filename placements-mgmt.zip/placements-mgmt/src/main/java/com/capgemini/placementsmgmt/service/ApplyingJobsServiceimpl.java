package com.capgemini.placementsmgmt.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.capgemini.placementsmgmt.entities.ApplyingJobs;
import com.capgemini.placementsmgmt.exceptions.RecordNotFoundException;
import com.capgemini.placementsmgmt.repository.ApplyingJobsRepository;

@Service
public class ApplyingJobsServiceimpl implements ApplyingJobsService {
	@Autowired
	ApplyingJobsRepository applyingjobsRepo;

	@Override
	public ApplyingJobs saveApplyingJobs(ApplyingJobs applyingjobs) {

		return applyingjobsRepo.save(applyingjobs);
	}

	@Override
	public List<ApplyingJobs> getAllApplyingJobs() {

		return applyingjobsRepo.findAll();
	}

	@Override
	public ApplyingJobs getApplyingJobById(int registrationid) {

		return applyingjobsRepo.findById(registrationid)
				.orElseThrow(() -> new RecordNotFoundException("Company with ID" + registrationid + " not found"));

	}

	@Override
	public void deleteApplyingJobsById(int registrationId) {
		ApplyingJobs applyingjobs = getApplyingJobById(registrationId);
		applyingjobsRepo.delete(applyingjobs);

	}

}
