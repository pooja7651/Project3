package com.capgemini.placementsmgmt.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.placementsmgmt.entities.ApplyJobs;
import com.capgemini.placementsmgmt.entities.Company;
import com.capgemini.placementsmgmt.service.CompanyService;

@RestController 

public class CompanyController {
	@Autowired

	CompanyService companyService;
	@PostMapping("/com/add")
	public Company  saveCompany(@RequestBody Company company) {
		return companyService.saveCompany(company);
	}


@GetMapping("/com/company")
public List<Company> getAllCompany(){
	return companyService.getAllCompany();

}
@GetMapping("/com/{id}")
public ResponseEntity<Company>  getCompanyById(@PathVariable int id) {
	System.out.println(id);
	
	Company company = companyService.getCompanyById(id);
	return new ResponseEntity<Company>(company,HttpStatus.OK);
	
}
}
