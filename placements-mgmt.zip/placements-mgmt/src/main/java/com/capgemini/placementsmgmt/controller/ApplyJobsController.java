package com.capgemini.placementsmgmt.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.placementsmgmt.entities.ApplyJobs;
import com.capgemini.placementsmgmt.entities.ApplyingJobs;
import com.capgemini.placementsmgmt.service.ApplyJobsService;


@RestController 

public class ApplyJobsController {
	@Autowired
	ApplyJobsService applyjobsService;
	
	@PostMapping("/job/add")
	public ApplyJobs saveApplyJobs(@RequestBody ApplyJobs applyjobs) {
		return applyjobsService.saveApplyJobs(applyjobs);
	}


@GetMapping("/job/appjob")
public List<ApplyJobs> getAllApplyJobs(){
	return applyjobsService.getAllApplyJobs();
	
	
}
@GetMapping("/jobs1/{id}")
public ResponseEntity<ApplyJobs> getApplyJobsById(@PathVariable int id) {
	System.out.println(id);
	
	ApplyJobs applyjobs = applyjobsService.getApplyJobById(id);
	return new ResponseEntity<ApplyJobs>(applyjobs,HttpStatus.OK);
	
}
@RequestMapping("/delete/{id}")
public String deleteCompany(@PathVariable(name="id") int registrationId) {
	applyjobsService.deleteApplyJobsById(registrationId);
	return "deleted the applied company for RegistrationId " +registrationId+ "";
	
}

	

}
