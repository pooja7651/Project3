package com.capgemini.placementsmgmt.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.capgemini.placementsmgmt.entities.Company;
import com.capgemini.placementsmgmt.exceptions.RecordNotFoundException;
import com.capgemini.placementsmgmt.repository.CompanyRepository;

@Service
public class CompanyServiceimpl implements CompanyService {
	@Autowired
	CompanyRepository companyRepo;

	@Override
	public Company saveCompany(Company company) {
		return companyRepo.save(company);
	}

	@Override
	public List<Company> getAllCompany() {
		return companyRepo.findAll();
	}

	@Override
	public Company getCompanyById(int id) {
		return companyRepo.findById(id)
				.orElseThrow(() -> new RecordNotFoundException("Company with  Id" + id + " not found"));
	}

}
