package com.capgemini.placementsmgmt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PlacementsMgmtApplication {

	public static void main(String[] args) {
		SpringApplication.run(PlacementsMgmtApplication.class, args);
	}

}
