package com.capgemini.placementsmgmt.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.capgemini.placementsmgmt.entities.ApplyJobs;
import com.capgemini.placementsmgmt.entities.MyProfile;
import com.capgemini.placementsmgmt.service.ApplyJobsService;
import com.capgemini.placementsmgmt.service.MyProfileService;


@Controller
public class ApplyJobsViewController {
	@Autowired
	ApplyJobsService  applyjobsservice;
	
	@RequestMapping("/apply")
	public String viewapplyjobsPage(Model model) {
		List<ApplyJobs > applyjobsList = applyjobsservice.getAllApplyJobs();
		model.addAttribute("applyjobsList",applyjobsList);
		return "applyjobs";
		
	}
	
	@RequestMapping(value="/saveapply",method= RequestMethod.POST)
	public String saveApplyJobs(@ModelAttribute("applyjobs") ApplyJobs applyjobs) {
		applyjobsservice.saveApplyJobs(applyjobs);
		return "redirect:/apply";
	}
	@RequestMapping("/add/{id}")
	public ModelAndView showAddApplyJobsPage(@PathVariable(name = "id") int registrationid) {
		ModelAndView mav = new ModelAndView("add_newcompany");
		ApplyJobs applyjobs = applyjobsservice.getApplyJobById(registrationid);
		mav.addObject("applyjobs",applyjobs);
		return mav;
	}
	
	

	
	
}
