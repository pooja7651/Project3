package com.capgemini.placementsmgmt.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.capgemini.placementsmgmt.entities.MyProfile;
import com.capgemini.placementsmgmt.service.MyProfileService;

@RestController

public class MyProfileController {
	@Autowired
	MyProfileService myprofileservice;

	@PostMapping("/profile/add")
	public MyProfile saveMyProfile(@RequestBody MyProfile myprofile) {
		return myprofileservice.saveMyProfile(myprofile);
	}

	@GetMapping("/profile/allprofiles")
	public List<MyProfile> getAllMyProfile() {
		return myprofileservice.getAllMyProfile();

	}

	@GetMapping("/profile/{id}")
	public ResponseEntity<MyProfile> getMyProfileById(@PathVariable int id) {
		System.out.println(id);

		MyProfile myprofile = myprofileservice.getMyProfileById(id);
		return new ResponseEntity<MyProfile>(myprofile, HttpStatus.OK);

	}

}
