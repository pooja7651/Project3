package com.capgemini.placementsmgmt.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;


import com.capgemini.placementsmgmt.entities.ApplyingJobs;

import com.capgemini.placementsmgmt.service.ApplyingJobsService;

@RestController

public class ApplyingJobsController {
	@Autowired
	ApplyingJobsService applyingjobsService;
	
	@PostMapping("/jobs/add")
	public ApplyingJobs saveApplyingJobs(@RequestBody ApplyingJobs applyingjobs) {
		return applyingjobsService.saveApplyingJobs(applyingjobs);
	}


@GetMapping("/jobs/appjob")
public List<ApplyingJobs> getAllApplyingJobs(){
	return applyingjobsService.getAllApplyingJobs();
	
}
@GetMapping("/jobs/{registrationid}")
public ResponseEntity<ApplyingJobs> getApplyingJobsById(@PathVariable int registrationid) {
	System.out.println(registrationid);
	
	ApplyingJobs applyingjobs = applyingjobsService.getApplyingJobById(registrationid);
	return new ResponseEntity<ApplyingJobs>(applyingjobs,HttpStatus.OK);
	
}

}
