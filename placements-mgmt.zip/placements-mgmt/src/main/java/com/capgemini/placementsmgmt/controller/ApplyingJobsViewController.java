package com.capgemini.placementsmgmt.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;


import com.capgemini.placementsmgmt.entities.ApplyingJobs;

import com.capgemini.placementsmgmt.service.ApplyingJobsService;
@Controller

public class ApplyingJobsViewController {
	@Autowired
	ApplyingJobsService  applyingjobsservice;
	
	@RequestMapping("/applying")
	public String viewapplyingjobsPage(Model model) {
		List<ApplyingJobs > applyingjobsList = applyingjobsservice.getAllApplyingJobs();
		model.addAttribute("applyingjobsList",applyingjobsList);
		return "applyingjobs";
		
	}
	
	@RequestMapping(value="/saveapplying",method= RequestMethod.POST)
	public String saveApplyingJobs(@ModelAttribute("applyingjobs") ApplyingJobs applyingjobs) {
		applyingjobsservice.saveApplyingJobs(applyingjobs);
		return "redirect:/applying";
	}
	@RequestMapping("/newcompany")
	public String showNewApplyingJobsPage(Model model) {
		ApplyingJobs applyingjobs = new ApplyingJobs();
		model.addAttribute("applyingjobs",applyingjobs);
		return "add_newcompany1";
	}
	@RequestMapping("/adding/{id}")
	public ModelAndView showAddApplyingJobsPage(@PathVariable(name = "id") int registrationid) {
		ModelAndView mav = new ModelAndView("add_newcompany1");
		ApplyingJobs applyingjobs = applyingjobsservice.getApplyingJobById(registrationid);
		mav.addObject("applyingjobs",applyingjobs);
		return mav;
	}


	@RequestMapping("/deleteing/{id}")
	public String deleteCompany(@PathVariable(name="id") int registrationId) {
		applyingjobsservice.deleteApplyingJobsById(registrationId);
		return "redirect:/applying";
	}

	

}
