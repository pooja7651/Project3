package com.capgemini.placementsmgmt.service;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.capgemini.placementsmgmt.entities.ApplyJobs;
import com.capgemini.placementsmgmt.entities.Company;
import com.capgemini.placementsmgmt.exceptions.RecordNotFoundException;
import com.capgemini.placementsmgmt.repository.ApplyJobsRepository;

@Service

public class ApplyJobsServiceimpl implements ApplyJobsService {
	@Autowired
	ApplyJobsRepository applyjobsRepo;
	@Autowired
	CompanyService companyService;

	@Override
	public ApplyJobs saveApplyJobs(ApplyJobs applyjobs) {
		Set<Company> companySet = new HashSet<Company>();
		Set<Company> companies = applyjobs.getCompany();
		companies.forEach(c -> {
			Company company = companyService.getCompanyById(c.getCompanyId());
			companySet.add(company);
		});
		applyjobs.setCompany(companySet);
		return applyjobsRepo.save(applyjobs);
	}

	@Override
	public List<ApplyJobs> getAllApplyJobs() {

		return applyjobsRepo.findAll();
	}

	@Override
	public ApplyJobs getApplyJobById(int id) {

		return applyjobsRepo.findById(id)
				.orElseThrow(() -> new RecordNotFoundException("RegistrationId with " + id + " not found"));
	}

	@Override
	public void deleteApplyJobsById(int registrationId) {
		ApplyJobs applyjobs = getApplyJobById(registrationId);
		applyjobsRepo.delete(applyjobs);

	}

}
