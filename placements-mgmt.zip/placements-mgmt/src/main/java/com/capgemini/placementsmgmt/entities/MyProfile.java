package com.capgemini.placementsmgmt.entities;

import java.sql.Date;
import java.util.Objects;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "myprofile")
public class MyProfile {
	@Id
	@Column(name = "registrationid")
	private int registrationid;
	@Column(name = "fullname")
	private String fullname;
	@Column(name = "emailid")
	private String emailid;
	@Column(name = "phnumber")
	private long phnumber;
	@Column(name = "dob")
	private Date dob;
	@Column(name = "gender")
	private String gender;
	// password
	@Column(name = "location")
	private String location;
	@Column(name = "qualification")
	private String qualification;
	@Column(name = "specialization")
	private String specialization;
	@Column(name = "cgpa")
	private Double cgpa;
	@Column(name = "course")
	private String course;
	@Column(name = "workexperience")
	private String workexperience;
	@Column(name = "hobbies")
	private String hobbies;

	public MyProfile() {
	}

	public int getRegistrationid() {
		return registrationid;
	}

	public void setRegistrationid(int registrationid) {
		this.registrationid = registrationid;
	}

	public String getFullname() {
		return fullname;
	}

	public void setFullname(String fullname) {
		this.fullname = fullname;
	}

	public String getEmailid() {
		return emailid;
	}

	public void setEmailid(String emailid) {
		this.emailid = emailid;
	}

	public long getPhnumber() {
		return phnumber;
	}

	public void setPhnumber(long phnumber) {
		this.phnumber = phnumber;
	}

	public Date getDob() {
		return dob;
	}

	public void setDob(Date dob) {
		this.dob = dob;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getQualification() {
		return qualification;
	}

	public void setQualification(String qualification) {
		this.qualification = qualification;
	}

	public String getSpecialization() {
		return specialization;
	}

	public void setSpecialization(String specialization) {
		this.specialization = specialization;
	}

	public Double getCgpa() {
		return cgpa;
	}

	public void setCgpa(Double cgpa) {
		this.cgpa = cgpa;
	}

	public String getCourse() {
		return course;
	}

	public void setCourse(String course) {
		this.course = course;
	}

	public String getWorkexperience() {
		return workexperience;
	}

	public void setWorkexperience(String workexperience) {
		this.workexperience = workexperience;
	}

	public String getHobbies() {
		return hobbies;
	}

	public void setHobbies(String hobbies) {
		this.hobbies = hobbies;
	}

	@Override
	public int hashCode() {
		return Objects.hash(cgpa, course, dob, emailid, fullname, gender, hobbies, location, phnumber, qualification,
				registrationid, specialization, workexperience);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		MyProfile other = (MyProfile) obj;
		return Objects.equals(cgpa, other.cgpa) && Objects.equals(course, other.course)
				&& Objects.equals(dob, other.dob) && Objects.equals(emailid, other.emailid)
				&& Objects.equals(fullname, other.fullname) && Objects.equals(gender, other.gender)
				&& Objects.equals(hobbies, other.hobbies) && Objects.equals(location, other.location)
				&& phnumber == other.phnumber && Objects.equals(qualification, other.qualification)
				&& registrationid == other.registrationid && Objects.equals(specialization, other.specialization)
				&& Objects.equals(workexperience, other.workexperience);
	}

	@Override
	public String toString() {
		return "MyProfile [registrationid=" + registrationid + ", fullname=" + fullname + ", emailid=" + emailid
				+ ", phnumber=" + phnumber + ", dob=" + dob + ", gender=" + gender + ", location=" + location
				+ ", qualification=" + qualification + ", specialization=" + specialization + ", cgpa=" + cgpa
				+ ", course=" + course + ", workexperience=" + workexperience + ", hobbies=" + hobbies + "]";
	}

}
