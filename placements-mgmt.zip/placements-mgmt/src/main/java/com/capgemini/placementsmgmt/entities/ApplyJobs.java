package com.capgemini.placementsmgmt.entities;

import java.util.Objects;
import java.util.Set;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name = "applyjobs")
public class ApplyJobs {
	@Id
	@Column(name = "registrstion_id")
	private int registrationId;
	@ManyToMany(fetch = FetchType.EAGER)
	@JoinTable(name = "applyjobs_company", joinColumns = @JoinColumn(name = "registration_id"), inverseJoinColumns = @JoinColumn(name = "companyId"))
	private Set<Company> company;
	@Column(name = "status")
	private String status;

	public ApplyJobs() {
	}

	public int getRegistrationId() {
		return registrationId;
	}

	public void setRegistrationId(int registrationId) {
		this.registrationId = registrationId;
	}

	public Set<Company> getCompany() {
		return company;
	}

	public void setCompany(Set<Company> company) {
		this.company = company;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@Override
	public int hashCode() {
		return Objects.hash(company, registrationId, status);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ApplyJobs other = (ApplyJobs) obj;
		return Objects.equals(company, other.company) && registrationId == other.registrationId
				&& Objects.equals(status, other.status);
	}

	@Override
	public String toString() {
		return "ApplyJobs [registrationId=" + registrationId + ", company=" + company + ", status=" + status + "]";
	}

}
