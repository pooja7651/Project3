package com.capgemini.placementsmgmt.service;

import java.util.List;
import com.capgemini.placementsmgmt.entities.ApplyingJobs;

public interface ApplyingJobsService {
	public ApplyingJobs saveApplyingJobs(ApplyingJobs applyingjobs);

	public List<ApplyingJobs> getAllApplyingJobs();

	public ApplyingJobs getApplyingJobById(int registrationid);

	public void deleteApplyingJobsById(int registrationId);
}
