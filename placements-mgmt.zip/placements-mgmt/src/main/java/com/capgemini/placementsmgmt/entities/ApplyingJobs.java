package com.capgemini.placementsmgmt.entities;

import java.util.Objects;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "applyingjobs")
public class ApplyingJobs {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "registrationid")
	private int registrationid;
	@Column(name = "companyName")
	private String companyName;
	@Column(name = "status")
	private String status;

	public ApplyingJobs() {
	}

	public int getRegistrationid() {
		return registrationid;
	}

	public void setRegistrationid(int registrationid) {
		this.registrationid = registrationid;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@Override
	public int hashCode() {
		return Objects.hash(companyName, registrationid, status);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ApplyingJobs other = (ApplyingJobs) obj;
		return Objects.equals(companyName, other.companyName) && registrationid == other.registrationid
				&& Objects.equals(status, other.status);
	}

	@Override
	public String toString() {
		return "ApplyingJobs [registrationid=" + registrationid + ", companyName=" + companyName + ", status=" + status
				+ "]";
	}

}
