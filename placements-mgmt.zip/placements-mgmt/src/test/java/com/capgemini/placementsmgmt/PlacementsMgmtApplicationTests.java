package com.capgemini.placementsmgmt;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.capgemini.placementsmgmt.entities.ApplyJobs;
import com.capgemini.placementsmgmt.entities.Company;
import com.capgemini.placementsmgmt.repository.ApplyJobsRepository;

@SpringBootTest
class PlacementsMgmtApplicationTests {
	@Autowired
	ApplyJobsRepository applyjobsrepo;
	
	
	@Test
	void contextLoads() {
	}
	@Test
	public void testgetApplyJobById() {
		ApplyJobs applyjobs = applyjobsrepo.findById(1234).get();
		applyjobs.setRegistrationId(7979);
	    applyjobs.setStatus("applied");
		applyjobsrepo.save(applyjobs);
		
	}
	

}
